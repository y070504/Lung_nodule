# Copyright (c) OpenMMLab. All rights reserved.
from .lora import LoRAModel

__all__ = [
    'LoRAModel',
]
