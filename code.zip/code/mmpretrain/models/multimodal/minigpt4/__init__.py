# Copyright (c) OpenMMLab. All rights reserved.
from .minigpt4 import MiniGPT4

__all__ = ['MiniGPT4']
