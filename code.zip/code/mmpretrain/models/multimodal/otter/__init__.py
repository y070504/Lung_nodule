# Copyright (c) OpenMMLab. All rights reserved.
from .otter import Otter

__all__ = ['Otter']
