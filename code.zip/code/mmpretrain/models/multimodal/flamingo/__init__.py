# Copyright (c) OpenMMLab. All rights reserved.
from .adapter import FlamingoLMAdapter
from .flamingo import Flamingo

__all__ = ['Flamingo', 'FlamingoLMAdapter']
