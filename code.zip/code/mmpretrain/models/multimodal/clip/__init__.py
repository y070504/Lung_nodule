# Copyright (c) OpenMMLab. All rights reserved.
from ..clip.clip import CLIP, CLIPZeroShot
from ..clip.clip_transformer import CLIPProjection, CLIPTransformer

__all__ = ['CLIP', 'CLIPZeroShot', 'CLIPTransformer', 'CLIPProjection']
