from copy import deepcopy
from typing import Sequence

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from mmcv.cnn import build_norm_layer
from mmcv.cnn.bricks.transformer import FFN
from mmengine.model import BaseModule, ModuleList
from mmcv.cnn import ConvModule

# from mmcls.utils import get_root_logger

import mmengine.logging.logger
from ..builder import BACKBONES
from ..utils import MultiheadAttention_modify, PatchEmbed, to_2tuple
from .base_backbone import BaseBackbone
from mmpretrain.registry import MODELS

class TransformerEncoderLayer(BaseModule):
    """Implements one encoder layer in Vision Transformer.

    Args:
        embed_dims (int): The feature dimension
        num_heads (int): Parallel attention heads
        feedforward_channels (int): The hidden dimension for FFNs
        drop_rate (float): Probability of an element to be zeroed
            after the feed forward layer. Defaults to 0.
        attn_drop_rate (float): The drop out rate for attention output weights.
            Defaults to 0.
        drop_path_rate (float): Stochastic depth rate. Defaults to 0.
        num_fcs (int): The number of fully-connected layers for FFNs.
            Defaults to 2.
        qkv_bias (bool): enable bias for qkv if True. Defaults to True.
        act_cfg (dict): The activation config for FFNs.
            Defaluts to ``dict(type='GELU')``.
        norm_cfg (dict): Config dict for normalization layer.
            Defaults to ``dict(type='LN')``.
        init_cfg (dict, optional): Initialization config dict.
            Defaults to None.
    """

    def __init__(self,
                 embed_dims,
                 num_heads,
                 feedforward_channels,
                 drop_rate=0.,
                 attn_drop_rate=0.,
                 drop_path_rate=0.,
                 num_fcs=2,
                 qkv_bias=True,
                 act_cfg=dict(type='GELU'),
                 norm_cfg=dict(type='LN'),
                 init_cfg=None):
        super(TransformerEncoderLayer, self).__init__(init_cfg=init_cfg)

        self.embed_dims = embed_dims

        self.norm1_name, norm1 = build_norm_layer(
            norm_cfg, self.embed_dims, postfix=1)
        self.add_module(self.norm1_name, norm1)

        self.attn = MultiheadAttention_modify(
            embed_dims=embed_dims,
            num_heads=num_heads,
            attn_drop=attn_drop_rate,
            proj_drop=drop_rate,
            dropout_layer=dict(type='DropPath', drop_prob=drop_path_rate),
            qkv_bias=qkv_bias)

        self.norm2_name, norm2 = build_norm_layer(
            norm_cfg, self.embed_dims, postfix=2)
        self.add_module(self.norm2_name, norm2)

        self.ffn = FFN(
            embed_dims=embed_dims,
            feedforward_channels=feedforward_channels,
            num_fcs=num_fcs,
            ffn_drop=drop_rate,
            dropout_layer=dict(type='DropPath', drop_prob=drop_path_rate),
            act_cfg=act_cfg)

    @property
    def norm1(self):
        return getattr(self, self.norm1_name)

    @property
    def norm2(self):
        return getattr(self, self.norm2_name)

    def init_weights(self):
        super(TransformerEncoderLayer, self).init_weights()
        for m in self.ffn.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight)
                nn.init.normal_(m.bias, std=1e-6)

    def forward(self, x):
        identity = x
        out, weight = self.attn(self.norm1(x))
        x = identity + out
        x = self.ffn(self.norm2(x), identity=x)
        return x, weight


class SELayer(BaseModule):
    """Squeeze-and-Excitation Module.

    Args:
        channels (int): The input (and output) channels of the SE layer.
        squeeze_channels (None or int): The intermediate channel number of
            SElayer. Default: None, means the value of ``squeeze_channels``
            is ``make_divisible(channels // ratio, divisor)``.
        ratio (int): Squeeze ratio in SELayer, the intermediate channel will
            be ``make_divisible(channels // ratio, divisor)``. Only used when
            ``squeeze_channels`` is None. Default: 16.
        divisor(int): The divisor to true divide the channel number. Only
            used when ``squeeze_channels`` is None. Default: 8.
        conv_cfg (None or dict): Config dict for convolution layer. Default:
            None, which means using conv2d.
        act_cfg (dict or Sequence[dict]): Config dict for activation layer.
            If act_cfg is a dict, two activation layers will be configurated
            by this dict. If act_cfg is a sequence of dicts, the first
            activation layer will be configurated by the first dict and the
            second activation layer will be configurated by the second dict.
            Default: (dict(type='ReLU'), dict(type='Sigmoid'))
    """

    def __init__(self,
                 channels,
                 squeeze_channels,
                 bias='auto',
                 conv_cfg=None,
                 act_cfg=(dict(type='ReLU'), dict(type='Sigmoid')),
                 init_cfg=None):
        super(SELayer, self).__init__(init_cfg)
        self.global_avgpool = nn.AdaptiveAvgPool2d(1)
        self.conv1 = ConvModule(
            in_channels=channels,
            out_channels=squeeze_channels,
            kernel_size=1,
            stride=1,
            bias=bias,
            conv_cfg=conv_cfg,
            act_cfg=act_cfg[0])
        self.conv2 = ConvModule(
            in_channels=squeeze_channels,
            out_channels=channels,
            kernel_size=1,
            stride=1,
            bias=bias,
            conv_cfg=conv_cfg,
            act_cfg=act_cfg[1])

    def forward(self, x): #jianan x:[768,12,197,197]
        out = self.global_avgpool(x) #jianan [768,12,1,1]
        out = self.conv1(out) #jianan [768,24,1,1]
        out = self.conv2(out) #jianan [768,12,1,1]
        return x * out


# import numpy as np
# import torch
# from torch import nn
# from torch.nn import init
# from collections import OrderedDict



# class ECAAttention(nn.Module):

#     def __init__(self, kernel_size=3):
#         super().__init__()
#         self.gap=nn.AdaptiveAvgPool2d(1)
#         self.conv=nn.Conv1d(1,1,kernel_size=kernel_size,padding=(kernel_size-1)//2)
#         self.sigmoid=nn.Sigmoid()

#     def init_weights(self):
#         for m in self.modules():
#             if isinstance(m, nn.Conv2d):
#                 init.kaiming_normal_(m.weight, mode='fan_out')
#                 if m.bias is not None:
#                     init.constant_(m.bias, 0)
#             elif isinstance(m, nn.BatchNorm2d):
#                 init.constant_(m.weight, 1)
#                 init.constant_(m.bias, 0)
#             elif isinstance(m, nn.Linear):
#                 init.normal_(m.weight, std=0.001)
#                 if m.bias is not None:
#                     init.constant_(m.bias, 0)

#     def forward(self, x):
#         y=self.gap(x) #bs,c,1,1
#         y=y.squeeze(-1).permute(0,2,1) #bs,1,c
#         y=self.conv(y) #bs,1,c
#         y=self.sigmoid(y) #bs,1,c
#         y=y.permute(0,2,1).unsqueeze(-1) #bs,c,1,1
#         return x*y.expand_as(x)



# class h_sigmoid(nn.Module):
#     def __init__(self, inplace=True):
#         super(h_sigmoid, self).__init__()
#         self.relu = nn.ReLU6(inplace=inplace)

#     def forward(self, x):
#         return self.relu(x + 3) / 6

# class h_swish(nn.Module):
#     def __init__(self, inplace=True):
#         super(h_swish, self).__init__()
#         self.sigmoid = h_sigmoid(inplace=inplace)

#     def forward(self, x):
#         return x * self.sigmoid(x)

# class CoordAtt(nn.Module):
#     def __init__(self, inp, oup, reduction=32):
#         super(CoordAtt, self).__init__()
#         self.pool_h = nn.AdaptiveAvgPool2d((None, 1))
#         self.pool_w = nn.AdaptiveAvgPool2d((1, None))

#         mip = max(8, inp // reduction)

#         self.conv1 = nn.Conv2d(inp, mip, kernel_size=1, stride=1, padding=0)
#         self.bn1 = nn.BatchNorm2d(mip)
#         self.act = h_swish()
        
#         self.conv_h = nn.Conv2d(mip, oup, kernel_size=1, stride=1, padding=0)
#         self.conv_w = nn.Conv2d(mip, oup, kernel_size=1, stride=1, padding=0)
        

#     def forward(self, x):
#         identity = x
        
#         n,c,h,w = x.size()
#         x_h = self.pool_h(x)
#         x_w = self.pool_w(x).permute(0, 1, 3, 2)

#         y = torch.cat([x_h, x_w], dim=2)
#         y = self.conv1(y)
#         y = self.bn1(y)
#         y = self.act(y) 
        
#         x_h, x_w = torch.split(y, [h, w], dim=2)
#         x_w = x_w.permute(0, 1, 3, 2)

#         a_h = self.conv_h(x_h).sigmoid()
#         a_w = self.conv_w(x_w).sigmoid()

#         out = identity * a_w * a_h

#         return out

# class SparseAttention(BaseModule):
#     def __init__(self, channels, squeeze_channels):
#         super(SparseAttention, self).__init__()
#         self.ECA_layer = ECAAttention(kernel_size=3)
        
#     def forward(self, x):
#         """
#         This model select the discriminative tokens for the last encoder layer input
#         Args:
#             x (List): The attention weights of each encoder layer, x with the shape [num_layer, B, num_heads, N, N]
#         Returns:
#             torch.Tensor: The selected Patch of the image [B, num_heads]
#         """
#         assert len(x.shape) == 5, \
#             'input x must with shape [num_layers, B, num_heads, N, N]'
#         num_layers, B, num_heads, N, _ = x.shape
#         # learn the layer weight so permute x with shape [B, num_heads, num_layers, N, N]

#         x = x.permute(1, 2, 0, 3, 4).contiguous() #jianan [64,12,12,197,197]
#         x = x.reshape(B * num_heads, num_layers, N, N)  #jianan [768,12,197,197]
#         x = self.ECA_layer(x)  #jianan [768,12,197,197]        
#         x = x.reshape(B, num_heads, num_layers, N, N) #jianan [64,12,12,197,197]
#         x = torch.sum(x, dim=2) #jianan [64,12,197,197]
#         # last_attn = x[0]
#         # for i in range(1, num_layer):
#         #     last_attn = torch.matmul(x[i], last_attn)
#         x = x[:, :, 0, 1:]  #jianan [64,12,196]
#         return x


class SparseAttention(BaseModule):
    def __init__(self, channels, squeeze_channels):
        super(SparseAttention, self).__init__()
        self.se_layer = SELayer(channels=channels, squeeze_channels=squeeze_channels)

    def forward(self, x):
        """
        This model select the discriminative tokens for the last encoder layer input
        Args:
            x (List): The attention weights of each encoder layer, x with the shape [num_layer, B, num_heads, N, N]
        Returns:
            torch.Tensor: The selected Patch of the image [B, num_heads]
        """
        assert len(x.shape) == 5, \
            'input x must with shape [num_layers, B, num_heads, N, N]'
        num_layers, B, num_heads, N, _ = x.shape
        # learn the layer weight so permute x with shape [B, num_heads, num_layers, N, N]

        x = x.permute(1, 2, 0, 3, 4).contiguous() #jianan [64,12,12,197,197]
        x = x.reshape(B * num_heads, num_layers, N, N)  #jianan [768,12,197,197]
        x = self.se_layer(x)  #jianan [768,12,197,197]        
        x = x.reshape(B, num_heads, num_layers, N, N) #jianan [64,12,12,197,197]
        x = torch.sum(x, dim=2) #jianan [64,12,197,197]
        # last_attn = x[0]
        # for i in range(1, num_layer):
        #     last_attn = torch.matmul(x[i], last_attn)
        x = x[:, :, 0, 1:]  #jianan [64,12,196]
        return x





@BACKBONES.register_module()
class VisionTransformerCell(BaseBackbone):
    """Vision Transformer.

    A PyTorch implement of : `An Image is Worth 16x16 Words:
    Transformers for Image Recognition at
    Scale<https://arxiv.org/abs/2010.11929>`_

    Args:
        arch (str | dict): Vision Transformer architecture
            Default: 'b'
        img_size (int | tuple): Input image size
        patch_size (int | tuple): The patch size
        out_indices (Sequence | int): Output from which stages.
            Defaults to -1, means the last stage.
        drop_rate (float): Probability of an element to be zeroed.
            Defaults to 0.
        drop_path_rate (float): stochastic depth rate. Defaults to 0.
        norm_cfg (dict): Config dict for normalization layer.
            Defaults to ``dict(type='LN')``.
        final_norm (bool): Whether to add a additional layer to normalize
            final feature map. Defaults to True.
        output_cls_token (bool): Whether output the cls_token. If set True,
            `with_cls_token` must be True. Defaults to True.
        interpolate_mode (str): Select the interpolate mode for position
            embeding vector resize. Defaults to "bicubic".
        patch_cfg (dict): Configs of patch embeding. Defaults to an empty dict.
        layer_cfgs (Sequence | dict): Configs of each transformer layer in
            encoder. Defaults to an empty dict.
        init_cfg (dict, optional): Initialization config dict.
            Defaults to None.
    """
    arch_zoo = {
        **dict.fromkeys(
            ['s', 'small'], {
                'embed_dims': 768,
                'num_layers': 8,
                'num_heads': 8,
                'feedforward_channels': 768 * 3,
                'qkv_bias': False
            }),
        **dict.fromkeys(
            ['b', 'base'], {
                'embed_dims': 768,
                'num_layers': 12,
                'num_heads': 12,
                'feedforward_channels': 3072
            }),
        **dict.fromkeys(
            ['l', 'large'], {
                'embed_dims': 1024,
                'num_layers': 24,
                'num_heads': 16,
                'feedforward_channels': 4096
            }),
    }

    def __init__(self,
                 arch='b',
                 img_size=224,
                 patch_size=16,
                 out_indices=-1,
                 drop_rate=0.,
                 drop_path_rate=0.,
                 norm_cfg=dict(type='LN', eps=1e-6),
                 final_norm=True,
                 output_cls_token=True,
                 interpolate_mode='bicubic',
                 patch_cfg=dict(),
                 layer_cfgs=dict(),
                 init_cfg=None):
        super(VisionTransformerCell, self).__init__(init_cfg)

        if isinstance(arch, str):
            arch = arch.lower()
            assert arch in set(self.arch_zoo), \
                f'Arch {arch} is not in default archs {set(self.arch_zoo)}'
            self.arch_settings = self.arch_zoo[arch]
        else:
            essential_keys = {
                'embed_dims', 'num_layers', 'num_heads', 'feedforward_channels'
            }
            assert isinstance(arch, dict) and set(arch) == essential_keys, \
                f'Custom arch needs a dict with keys {essential_keys}'
            self.arch_settings = arch

        self.embed_dims = self.arch_settings['embed_dims']
        self.num_layers = self.arch_settings['num_layers']
        self.img_size = to_2tuple(img_size)

        # Set patch embedding
        _patch_cfg = dict(
            img_size=img_size,
            embed_dims=self.embed_dims,
            conv_cfg=dict(
                type='Conv2d', kernel_size=patch_size, stride=patch_size),
        )
        _patch_cfg.update(patch_cfg)     #{'img_size': 224, 'embed_dims': 768, 'conv_cfg': {'type': 'Conv2d', 'kernel_size': 16, 'stride': 16}}
        self.patch_embed = PatchEmbed(**_patch_cfg) #PatchEmbed(  (projection): Conv2d(3, 768, kernel_size=(16, 16), stride=(16, 16)))
        num_patches = self.patch_embed.num_patches

        # Set cls token
        self.output_cls_token = output_cls_token
        self.cls_token = nn.Parameter(torch.zeros(1, 1, self.embed_dims)) #[1,1,768]

        # Set position embedding
        self.interpolate_mode = interpolate_mode
        self.pos_embed = nn.Parameter(
            torch.zeros(1, num_patches + 1, self.embed_dims)) #[1,197,768]
        self.drop_after_pos = nn.Dropout(p=drop_rate)

        if isinstance(out_indices, int):
            out_indices = [out_indices]
        assert isinstance(out_indices, Sequence), \
            f'"out_indices" must by a sequence or int, ' \
            f'get {type(out_indices)} instead.'
        for i, index in enumerate(out_indices):
            if index < 0:
                out_indices[i] = self.num_layers + index
                assert out_indices[i] >= 0, f'Invalid out_indices {index}'
        self.out_indices = out_indices   #默认最后一层11

        # stochastic depth decay rule
        dpr = np.linspace(0, drop_path_rate, self.arch_settings['num_layers']) # array([0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.])

        self.layers = ModuleList()
        if isinstance(layer_cfgs, dict):
            layer_cfgs = [layer_cfgs] * self.num_layers
        for i in range(self.num_layers):
            _layer_cfg = dict(
                embed_dims=self.embed_dims,
                num_heads=self.arch_settings['num_heads'],
                feedforward_channels=self.
                arch_settings['feedforward_channels'],
                drop_rate=drop_rate,
                drop_path_rate=dpr[i],
                qkv_bias=self.arch_settings.get('qkv_bias', True),
                norm_cfg=norm_cfg)
            _layer_cfg.update(layer_cfgs[i])
            self.layers.append(TransformerEncoderLayer(**_layer_cfg))
        # attention patch selection module
        self.attn_select = SparseAttention(channels=self.num_layers, squeeze_channels=2 * self.num_layers)
        select_layer_cfg = dict(
            embed_dims=self.embed_dims,
            num_heads=self.arch_settings['num_heads'],
            feedforward_channels=self.
                arch_settings['feedforward_channels'],
            drop_rate=drop_rate,
            drop_path_rate=dpr[i],
            qkv_bias=self.arch_settings.get('qkv_bias', True),
            norm_cfg=norm_cfg
        )
        select_layer_cfg.update(layer_cfgs[0])
        # attention encoder module
        self.attn_encoder = TransformerEncoderLayer(**select_layer_cfg)
        self.final_norm = final_norm
        if final_norm:
            self.norm1_name, norm1 = build_norm_layer(
                norm_cfg, self.embed_dims, postfix=1)
            self.add_module(self.norm1_name, norm1)

    @property
    def norm1(self):
        return getattr(self, self.norm1_name)

    def init_weights(self):
        # Suppress default init if use pretrained model.
        # And use custom load_checkpoint function to load checkpoint.
        if (isinstance(self.init_cfg, dict)
                and self.init_cfg['type'] == 'Pretrained'):
            init_cfg = deepcopy(self.init_cfg)
            init_cfg.pop('type')
            self._load_checkpoint(**init_cfg)
        else:
            super(VisionTransformerCell, self).init_weights()
            # Modified from ClassyVision
            nn.init.normal_(self.pos_embed, std=0.02)

    def _load_checkpoint(self, checkpoint, prefix=None, map_location=None):
        # from mmcv.runner import (_load_checkpoint,
        #                          _load_checkpoint_with_prefix, load_state_dict)
        from mmengine.runner.checkpoint import (_load_checkpoint,
                                 _load_checkpoint_with_prefix, load_state_dict)
        # from mmcv.utils import print_log
        from mmengine.logging import print_log
        logger = mmengine.logging.MMLogger.get_instance(name='MMLogger',
                              logger_name='Logger')

        if prefix is None:
            print_log(f'load model from: {checkpoint}', logger=logger)
            checkpoint = _load_checkpoint(checkpoint, map_location, logger)
            # get state_dict from checkpoint
            if 'state_dict' in checkpoint:
                state_dict = checkpoint['state_dict']
            else:
                state_dict = checkpoint
        else:
            print_log(
                f'load {prefix} in model from: {checkpoint}', logger=logger)
            state_dict = _load_checkpoint_with_prefix(prefix, checkpoint,
                                                      map_location)

        if 'pos_embed' in state_dict.keys():
            ckpt_pos_embed_shape = state_dict['pos_embed'].shape
            if self.pos_embed.shape != ckpt_pos_embed_shape:
                print_log(
                    f'Resize the pos_embed shape from {ckpt_pos_embed_shape} '
                    f'to {self.pos_embed.shape}.',
                    logger=logger)

                ckpt_pos_embed_shape = to_2tuple(
                    int(np.sqrt(ckpt_pos_embed_shape[1] - 1)))
                pos_embed_shape = self.patch_embed.patches_resolution

                state_dict['pos_embed'] = self.resize_pos_embed(
                    state_dict['pos_embed'], ckpt_pos_embed_shape,
                    pos_embed_shape, self.interpolate_mode)

        # load state_dict
        load_state_dict(self, state_dict, strict=False, logger=logger)

    @staticmethod
    def resize_pos_embed(pos_embed, src_shape, dst_shape, mode='bicubic'):
        """Resize pos_embed weights.

        Args:
            pos_embed (torch.Tensor): Position embedding weights with shape
                [1, L, C].
            src_shape (tuple): The resolution of downsampled origin training
                image.
            dst_shape (tuple): The resolution of downsampled new training
                image.
            mode (str): Algorithm used for upsampling:
                ``'nearest'`` | ``'linear'`` | ``'bilinear'`` | ``'bicubic'`` |
                ``'trilinear'``. Default: ``'bicubic'``
        Return:
            torch.Tensor: The resized pos_embed of shape [1, L_new, C]
        """
        assert pos_embed.ndim == 3, 'shape of pos_embed must be [1, L, C]'
        _, L, C = pos_embed.shape
        src_h, src_w = src_shape
        assert L == src_h * src_w + 1
        cls_token = pos_embed[:, :1]

        src_weight = pos_embed[:, 1:]
        src_weight = src_weight.reshape(1, src_h, src_w, C).permute(0, 3, 1, 2)

        dst_weight = F.interpolate(
            src_weight, size=dst_shape, align_corners=False, mode=mode)
        dst_weight = torch.flatten(dst_weight, 2).transpose(1, 2)

        return torch.cat((cls_token, dst_weight), dim=1)

    def forward(self, x):
        B = x.shape[0]      #jianan(x:[64,3,224,224])
        x = self.patch_embed(x)     #jianan([24,196,768])
        patch_resolution = self.patch_embed.patches_resolution #jianan [14,14]

        # stole cls_tokens impl from Phil Wang, thanks
        cls_tokens = self.cls_token.expand(B, -1, -1) #jianan[1,1,768]->[24,1,768]
        x = torch.cat((cls_tokens, x), dim=1) #jianan([24,197,768])
        x = x + self.pos_embed
        x = self.drop_after_pos(x)

        outs = []
        attn_weights = []
        for i, layer in enumerate(self.layers):
            x, weights = layer(x)
            attn_weights.append(weights)
            if i == len(self.layers) - 1 and self.final_norm:
                x = self.norm1(x)
        attn_weights = torch.stack(attn_weights, dim=0) #jianan attn_weights[12,24,12,197,197]
        attn = self.attn_select(attn_weights) # jianan attn[24,12,196]  SparseAttention注意力 
        _, patch_select = attn.max(2)   # select the max head with the token jianan 全为[24,12]
        # select the graph patch so need to add 1 here
        patch_select = patch_select + 1 #jianan[64,12]
        attn_parts = []
        B, _, C = x.shape  #jianan [64,197,768]
        # print(patch_select)
        for i in range(B):
            t = x[i, patch_select[i, :]] #jianan [12,768]
            # print(patch_select[i, :])
            # print(t)
            attn_parts.append(x[i, patch_select[i, :]]) #jianan x[24,197,768],attn_parts中的每个元素的维度是[12,768]
        attn_parts = torch.stack(attn_parts)#jianan [24,12,768]
        r = x[:,0]
        # print(x[:,0])
        # print(r.unsqueeze(1))
        attn_parts = torch.cat((x[:, 0].unsqueeze(1), attn_parts), dim=1)#jianan [24,13,768]
        attn_encoded_parts, _ = self.attn_encoder(attn_parts) #jianan [24,13,768]
        patch_token = attn_encoded_parts[:, 1:] #jianan [24,12,768]
        cls_token = attn_encoded_parts[:, 0] #jianan [24,768]
        if self.output_cls_token:
            out = [patch_token, cls_token]
        else:
            out = patch_token
        # outs = [out]
        # return tuple(outs)
        return out
